# TypeScript-In-Depth

1. > npm install -g typescript gulp
2. > npm install
3. > gulp